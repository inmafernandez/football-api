export const COMPETITION_ID = 2014; // La Liga
export const TEAM_ID = 81; // F.C. Barcelona
